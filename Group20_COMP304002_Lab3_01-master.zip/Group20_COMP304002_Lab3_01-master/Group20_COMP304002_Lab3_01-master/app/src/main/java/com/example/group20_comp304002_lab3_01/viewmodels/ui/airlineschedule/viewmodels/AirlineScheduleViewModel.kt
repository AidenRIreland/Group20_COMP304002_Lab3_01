package com.example.group20_comp304002_lab3_01.viewmodels.ui.airlineschedule.viewmodels
import androidx.lifecycle.ViewModel
import androidx.lifecycle.liveData
import kotlinx.coroutines.Dispatchers

class AirlineScheduleViewModel : ViewModel() {


}